* SPICE NETLIST
***************************************

.SUBCKT nand3gate in1 gnd in2 in3 vdd out
** N=8 EP=6 IP=0 FDC=6
M0 7 in1 gnd gnd NMOS_VTG L=5e-08 W=1.2e-07 AD=1.68e-14 AS=1.35e-14 PD=5.2e-07 PS=4.65e-07 $X=930 $Y=2365 $D=5
M1 8 in2 7 gnd NMOS_VTG L=5e-08 W=1.2e-07 AD=1.68e-14 AS=1.68e-14 PD=5.2e-07 PS=5.2e-07 $X=1310 $Y=2365 $D=5
M2 out in3 8 gnd NMOS_VTG L=5e-08 W=1.2e-07 AD=1.41e-14 AS=1.68e-14 PD=4.75e-07 PS=5.2e-07 $X=1690 $Y=2365 $D=5
M3 out in1 vdd vdd PMOS_VTG L=5e-08 W=2.4e-07 AD=3.36e-14 AS=2.7e-14 PD=7.6e-07 PS=7.05e-07 $X=930 $Y=3375 $D=4
M4 vdd in2 out vdd PMOS_VTG L=5e-08 W=2.4e-07 AD=3.36e-14 AS=3.36e-14 PD=7.6e-07 PS=7.6e-07 $X=1310 $Y=3375 $D=4
M5 out in3 vdd vdd PMOS_VTG L=5e-08 W=2.4e-07 AD=2.82e-14 AS=3.36e-14 PD=7.15e-07 PS=7.6e-07 $X=1690 $Y=3375 $D=4
.ENDS
***************************************
