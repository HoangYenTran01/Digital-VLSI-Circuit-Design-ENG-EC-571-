* SPICE NETLIST
***************************************

.SUBCKT Inverter in vdd gnd out
** N=4 EP=4 IP=0 FDC=2
M0 out in gnd gnd NMOS_VTG L=5e-08 W=9e-08 AD=9.675e-15 AS=1.0125e-14 PD=3.95e-07 PS=4.05e-07 $X=-9460 $Y=-6090 $D=5
M1 out in vdd vdd PMOS_VTG L=5e-08 W=1.8e-07 AD=2.025e-14 AS=2.025e-14 PD=5.85e-07 PS=5.85e-07 $X=-9460 $Y=-5470 $D=4
.ENDS
***************************************
